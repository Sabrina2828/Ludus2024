const config = {
    type: Phaser.AUTO,
    parent: "canvas-wrapper",
    width: 800,
    height: 600,
    scene: [Accueil, CommentJouerScene, CreditsScene, JeuScene, PartieTerminee, Victoire]
};
const game = new Phaser.Game(config);