class CreditsScene extends Phaser.Scene {
  constructor() {
    super("Credits");
  }

  preload() {
    this.load.image("quitter", "./assets/images/quitter.png");
  }

  create() {
    const quitter = this.add
      .image(750, 50, "quitter")
      .setScale(0.1)
      .setInteractive();

    quitter.on("pointerdown", () => {
      this.scene.start("Accueil");
    });
  }

  update() {}
}
