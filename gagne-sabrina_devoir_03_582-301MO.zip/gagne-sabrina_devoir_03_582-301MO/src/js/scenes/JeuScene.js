class JeuScene extends Phaser.Scene {
  constructor() {
    super("Jeu");
  }

  preload() {
    this.load.image("quitter", "./assets/images/quitter.png");
    this.load.image("victoire", "./assets/images/victoire.png");
    this.load.image("partieTerminee", "./assets/images/partieterminee.png");
  }

  create() {
    let background = this.add
      .image(config.width / 2, config.height / 2, "background")
      .setScale(0.5);

    let logo = this.add.image(0, 0, "logo").setOrigin(0.1, 0.05).setScale(0.06);

    let audio = this.add
      .image(0, config.height, "audio")
      .setOrigin(-0.2, 1.3)
      .setScale(0.13);

    const quitter = this.add
      .image(750, 50, "quitter")
      .setScale(0.1)
      .setInteractive();

    quitter.on("pointerdown", () => {
      this.scene.start("Accueil");
    });

    const victoire = this.add
      .image(200, 300, "victoire")
      .setScale(0.5)
      .setInteractive();

    victoire.on("pointerdown", () => {
      this.scene.start("Victoire");
    });

    const partieTerminee = this.add
      .image(600, 300, "partieTerminee")
      .setScale(0.2)
      .setInteractive();

    partieTerminee.on("pointerdown", () => {
      this.scene.start("PartieTerminee");
    });
  }

  update() {}
}
