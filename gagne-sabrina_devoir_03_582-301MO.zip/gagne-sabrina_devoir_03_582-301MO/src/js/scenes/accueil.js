class Accueil extends Phaser.Scene {
  constructor() {
    super({ key: "Accueil" });
  }

  preload() {
    this.load.image("background", "./assets/images/background.png");
    this.load.image("logo", "./assets/images/logo (1).png");
    this.load.image("how", "./assets/images/commentJouer.png");
    this.load.image("start", "./assets/images/jouer.png");
    this.load.image("credits", "./assets/images/credits.png");
    this.load.image("audio", "./assets/images/audio.png");
  }

  create() {
    let background = this.add
      .image(config.width / 2, config.height / 2, "background")
      .setScale(0.5);

    let logo = this.add.image(0, 0, "logo").setOrigin(0.1, 0.05).setScale(0.06);

    let audio = this.add
      .image(0, config.height, "audio")
      .setOrigin(-0.2, 1.3)
      .setScale(0.13);

    const start = this.add
      .image(config.width / 2, config.height / 2, "start")
      .setScale(0.2);
    start.setInteractive();
    start.on("pointerdown", () => {
      this.scene.start("Jeu");
    });

    const credits = this.add
      .image(config.width / 2, config.height - 50, "credits")
      .setScale(0.4)
      .setOrigin(0.5, 1.5);
    credits.setInteractive();
    credits.on("pointerdown", () => {
      this.scene.start("Credits");
    });

    const how = this.add.image(735, 70, "how").setScale(0.1).setOrigin(0, 0);
    how.setInteractive();
    how.on("pointerdown", () => {
      this.scene.start("CommentJouer");
    });
  }
}
