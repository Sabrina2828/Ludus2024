class Victoire extends Phaser.Scene {
  constructor() {
    super({ key: "Victoire" });
  }

  preload() {
    this.load.image("quitter", "./assets/images/quitter.png");
    this.load.image("retour", "./assets/images/retour.png");
  }

  create() {
    const quitter = this.add
      .image(750, 50, "quitter")
      .setScale(0.1)
      .setInteractive();

    quitter.on("pointerdown", () => {
      this.scene.start("Accueil");
    });
    const retour = this.add
      .image(20, 20, "retour")
      .setScale(0.1)
      .setOrigin(0, 0);
    retour.setInteractive();
    retour.on("pointerdown", () => {
      this.scene.start("Jeu");
    });
  }

  update() {}
}
